class QuoteDraftService:
    pass
