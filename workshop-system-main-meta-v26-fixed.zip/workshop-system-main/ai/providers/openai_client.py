class OpenAIClient:
    pass
