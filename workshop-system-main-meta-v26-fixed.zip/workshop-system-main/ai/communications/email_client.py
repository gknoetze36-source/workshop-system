class EmailClient:
    pass
