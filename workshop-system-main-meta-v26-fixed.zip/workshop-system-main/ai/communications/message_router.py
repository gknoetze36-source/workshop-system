class MessageRouter:
    pass
