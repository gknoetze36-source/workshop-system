class VehicleRepository: pass
