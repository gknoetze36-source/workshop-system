class QuoteRepository: pass
