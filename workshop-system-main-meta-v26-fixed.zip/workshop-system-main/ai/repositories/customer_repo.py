class CustomerRepository: pass
