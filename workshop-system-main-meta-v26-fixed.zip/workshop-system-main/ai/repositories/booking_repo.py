class BookingRepository: pass
