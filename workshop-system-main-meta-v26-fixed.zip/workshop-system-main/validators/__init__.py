"""Local PHANTA request validators."""
